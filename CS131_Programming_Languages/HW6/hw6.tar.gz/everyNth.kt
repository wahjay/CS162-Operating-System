

fun everyNth(list: List<Any>, N: Int): List<Any> {


    var temp_list : List<Any> = listOf()

    for(index in list.indices) {

        if((index + 1) % N == 0)
	   temp_list += list[index]
    }

    
    return temp_list
}


fun main() {
    val items = listOf(1,2,3,4,5,6,7,8,9)
    val things = listOf("Apple", "Banana", "Cat", "Dog", "Ear", "Fido")
    val result1 = everyNth(items,2)
    val result2 = everyNth(things,3)
    println(result1)
    println(result2)
}